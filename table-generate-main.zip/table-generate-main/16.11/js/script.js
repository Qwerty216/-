let table = document.querySelector('#table');
let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];

const newTab = () => {
    let col = document.querySelector('#inp').value;
    // console.log(col);
    let rows = Math.ceil(arr.length / col);

    for(let i = 0; i < rows; i++){
        let tr = document.createElement('tr');
        for(let k = 0; k < col; k++){
            let td = document.createElement('td');
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }

    let cells = table.querySelectorAll('td');
    for(n = 0; n < arr.length; n++){
        cells[n].innerText = arr[n];
    }
}