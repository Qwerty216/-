let fibo = [1, 2, 3];
let output = 0;

while (fibo[fibo.length-1] + fibo[fibo.length-2] <= 4000000) {
   fibo.push(Number(fibo[fibo.length-1] + fibo[fibo.length-2]));
}

for (let elem in fibo) {
    if (fibo[elem]%2==0) {
        output +=Number(fibo[elem]);
    }
}

console.log(output);

